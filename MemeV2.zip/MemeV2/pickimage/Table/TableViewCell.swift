//
//  TableViewCell.swift
//  pickimage
//
//  Created by Sayed  on 5/2/19.
//  Copyright © 2019 Sayed . All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    
    @IBOutlet weak var MemeImageView: UIImageView!
    @IBOutlet weak var label: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    

}
