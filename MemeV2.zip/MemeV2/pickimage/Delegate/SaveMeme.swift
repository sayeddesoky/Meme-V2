//
//  SaveMeme.swift
//  pickimage
//
//  Created by Sayed  on 4/22/19.
//  Copyright © 2019 Sayed . All rights reserved.
//

import Foundation
import UIKit

struct Meme {//structure of meme to save its info
    var topText: String
    var bottomText: String
    var originalImage: UIImage
    var memedImage: UIImage
}
