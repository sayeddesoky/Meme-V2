//
//  CollectionViewCell.swift
//  pickimage
//
//  Created by Sayed  on 5/2/19.
//  Copyright © 2019 Sayed . All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var memeImageView: UIImageView!
}
